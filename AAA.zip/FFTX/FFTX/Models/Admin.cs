﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FFTX.Models
{
    public class Admin
    {
        public string Admin_Id { get; set; }
        public string Admin_Password { get; set; }
        public string Admin_name { get; set; }
    }
}