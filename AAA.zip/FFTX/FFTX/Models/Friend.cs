﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FFTX.Models
{
    public class Friend
    {
        public string User_Id { get; set; }
        public string Follow_Id { get; set; }
        public int Group_Id { get; set; }
        public string Follow_Id_Remark { get; set; }
    }
}