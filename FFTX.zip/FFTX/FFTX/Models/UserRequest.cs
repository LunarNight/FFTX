﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FFTX.Models
{ 
    public class UserRequest
    {
        public string User_Id { get; set; }
        public DateTime Request_Time { get; set; }
    }
}