$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+992697+'&oi='+2167+'&ot=1&&url='+window.location, function(json){})    

});