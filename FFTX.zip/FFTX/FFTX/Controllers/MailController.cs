﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FFTX.Models;
using FFTX.ModelsSql;
namespace FFTX.Controllers
{
    public class MailController : Controller
    {
        //
        // GET: /Mail/

        //站内信页
        public ActionResult Index()
        {
            User user = new User();
            user.User_Id = ((User)Session["user"]).User_Id;
            //获取站内信相关信息
            Mail m = new Mail();
            MailSql msl = new MailSql();
            m.User_Id = user.User_Id;
            msl.getMailInfo(m);
            ViewBag.mail = m;

            //获取评论信息
            if (m.Comment_Num != 0)
            {
                List<Comment> clist = new CommentSql().getMailComments(m.User_Id);
                ViewBag.comment_list = clist;
            }
            else
            {
                ViewBag.CommentList = null;
            }
            //获取分享信息
            if (m.Share_Num != 0)
            {
                ViewBag.ShareList = null;
            }
            else
            {
                ViewBag.ShareList = null;
            }
            //获取点赞信息
            if (m.Like_Num != 0)
            {
                ViewBag.LikeList = null;
            }
            else
            {
                ViewBag.LikeList = null;
            }
            return View();
        }
        public ActionResult lookPhotoLike()
        {
            return View();
        }
        public ActionResult lookPhotoComment()
        {
            int cid = Int32.Parse(Request.QueryString["comment_id"]);
            //获取查看评论的id 将flag=1
            Comment c = new Comment();
            c.Comment_Id = cid;

            //获取站内信信息
            Mail m = new Mail();
            m.User_Id = ((User)Session["user"]).User_Id;
            MailSql msl = new MailSql();
            msl.getMailInfo(m);
            //改变未查看评论数量
            m.Comment_Num = m.Comment_Num - 1;

            //改变站内信数量 改变 评论查看位
            msl.lookComment(m,c);
            return RedirectToAction("Index");
        }
        public ActionResult lookBoardMessage()
        {
            return View();
        }
        public ActionResult lookPhotoShare()
        {
            return View();  
        }
    }
}
