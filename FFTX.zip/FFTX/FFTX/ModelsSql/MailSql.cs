﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FFTX.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace FFTX.ModelsSql
{
    public class MailSql
    {
        //新建用户拥有站内信
        public bool creatMail(Mail m)
        {
            return true;
        }
        public bool addMail(Mail m)
        {
            return true;
        }
        public bool emptyMail(Mail m)
        {
            return true;
        }
    }
}